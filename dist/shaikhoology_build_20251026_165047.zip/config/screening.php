<?php
return ['denominator'=>'assets','caps'=>['debt'=>0.25,'interest'=>0.025,'nonsh'=>0.025,'liquid'=>0.90],'review'=>'quarterly','run_ratios_only_for'=>'permissible'];
