<?php
return ['driver'=>'file','path'=>dirname(__DIR__).'/storage/cache'];
