<?php
namespace App\Services; class CacheService { public function get($k){return null;} public function set($k,$v,$ttl=300){} }
