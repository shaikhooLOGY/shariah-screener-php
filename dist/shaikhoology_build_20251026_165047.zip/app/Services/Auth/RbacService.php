<?php
namespace App\Services\Auth; class RbacService { public function can($user,$perm){return false;} }
