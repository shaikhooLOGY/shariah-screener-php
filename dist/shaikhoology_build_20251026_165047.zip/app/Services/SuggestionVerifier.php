<?php
namespace App\Services; class SuggestionVerifier { public function verify(array $s): array { return ['status'=>'pending']; } }
