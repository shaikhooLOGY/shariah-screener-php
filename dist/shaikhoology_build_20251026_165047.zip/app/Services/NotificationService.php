<?php
namespace App\Services; class NotificationService { public function send($userId,$msg){} }
