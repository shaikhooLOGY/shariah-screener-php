<?php
function percent($n){ return number_format($n*100,2).'%' ;}
function periodLabel($p){ return $p; }
