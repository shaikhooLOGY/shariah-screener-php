<?php
namespace App\Helpers; class Validators { public static function positive($n){ return $n>0; } }
