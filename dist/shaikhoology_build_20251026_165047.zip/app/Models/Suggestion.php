<?php
namespace App\Models;
use Core\Model;
class Suggestion extends Model {}
