<?php
namespace App\Models;
use Core\Model;
class Filing extends Model {}
