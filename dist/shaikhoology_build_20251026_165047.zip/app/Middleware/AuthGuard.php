<?php
namespace App\Middleware; class AuthGuard { public function handle(){ /* require login */ } }