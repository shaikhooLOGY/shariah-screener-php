<?php
namespace App\Middleware; class RoleGuard { public function handle($roles=[]){ /* check roles */ } }