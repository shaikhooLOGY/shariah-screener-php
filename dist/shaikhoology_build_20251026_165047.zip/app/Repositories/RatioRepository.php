<?php
namespace App\Repositories; class RatioRepository {}
