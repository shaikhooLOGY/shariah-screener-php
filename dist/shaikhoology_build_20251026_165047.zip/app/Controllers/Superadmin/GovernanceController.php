<?php
namespace App\Controllers\Superadmin;
use Core\Controller;
class GovernanceController extends Controller { public function index(){ $this->view('superadmin/governance'); } }