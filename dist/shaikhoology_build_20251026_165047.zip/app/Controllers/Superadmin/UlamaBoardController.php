<?php
namespace App\Controllers\Superadmin;
use Core\Controller;
class UlamaBoardController extends Controller { public function index(){ $this->view('superadmin/ulama'); } }