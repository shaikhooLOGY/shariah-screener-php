<?php
namespace Core; class View {}
