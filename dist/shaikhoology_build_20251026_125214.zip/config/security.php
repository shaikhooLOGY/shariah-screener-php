<?php
return ['csp'=>"default-src 'self' 'unsafe-inline' data:", 'hsts'=>true];
