<?php
return ['concurrency'=>2,'retries'=>3];
