<?php
return ['name'=>'Shaikhoology','env'=>$_ENV['APP_ENV']??'local','url'=>$_ENV['APP_URL']??'http://localhost'];
