<?php
namespace Core; class Response {}
