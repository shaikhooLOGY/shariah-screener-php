<?php
namespace App\Middleware; class InputSanitizer { public function clean($html){ return $html; } }