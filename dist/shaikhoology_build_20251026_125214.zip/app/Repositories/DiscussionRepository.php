<?php
namespace App\Repositories; class DiscussionRepository {}
