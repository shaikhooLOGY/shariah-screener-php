<?php
namespace App\Repositories; class CompanyRepository {}
