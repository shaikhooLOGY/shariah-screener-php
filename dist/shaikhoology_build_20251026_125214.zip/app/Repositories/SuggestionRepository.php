<?php
namespace App\Repositories; class SuggestionRepository {}
