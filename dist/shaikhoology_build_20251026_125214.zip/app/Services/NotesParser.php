<?php
namespace App\Services; class NotesParser { public function parse(string $text): array { return []; } }
