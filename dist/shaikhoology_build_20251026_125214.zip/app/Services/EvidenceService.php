<?php
namespace App\Services; class EvidenceService { public function store(){} public function signedUrl(){} }
