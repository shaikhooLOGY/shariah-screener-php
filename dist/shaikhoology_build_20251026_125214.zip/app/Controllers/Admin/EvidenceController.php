<?php
namespace App\Controllers\Admin;
use Core\Controller;
class EvidenceController extends Controller { public function index(){ $this->view('admin/evidence'); } }