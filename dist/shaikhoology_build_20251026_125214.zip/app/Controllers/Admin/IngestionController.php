<?php
namespace App\Controllers\Admin;
use Core\Controller;
class IngestionController extends Controller { public function index(){ $this->view('admin/ingestion'); } }