<?php
namespace App\Controllers\Mufti;
use Core\Controller;
class ProfileController extends Controller { public function edit(){ $this->view('mufti/profile'); } }