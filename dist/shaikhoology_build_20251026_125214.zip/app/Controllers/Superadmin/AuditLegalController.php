<?php
namespace App\Controllers\Superadmin;
use Core\Controller;
class AuditLegalController extends Controller { public function index(){ $this->view('superadmin/audit-legal'); } }