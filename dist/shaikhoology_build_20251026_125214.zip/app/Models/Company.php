<?php
namespace App\Models;
use Core\Model;
class Company extends Model {}
