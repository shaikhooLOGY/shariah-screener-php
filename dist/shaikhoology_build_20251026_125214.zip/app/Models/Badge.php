<?php
namespace App\Models;
use Core\Model;
class Badge extends Model {}
