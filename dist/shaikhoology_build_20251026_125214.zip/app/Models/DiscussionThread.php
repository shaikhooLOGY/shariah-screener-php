<?php
namespace App\Models;
use Core\Model;
class DiscussionThread extends Model {}
