<?php
namespace App\Models;
use Core\Model;
class DiscussionPost extends Model {}
