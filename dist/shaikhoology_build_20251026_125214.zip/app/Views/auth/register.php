<?php $title = 'Register'; ob_start(); ?>
<h1>Create Account</h1>
<p>Request portal access for your Shari'ah board or compliance team. Approvals are handled manually today.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
