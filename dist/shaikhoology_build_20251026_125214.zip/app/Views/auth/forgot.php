<?php $title = 'Forgot Password'; ob_start(); ?>
<h1>Forgot Password</h1>
<p>Enter your registered email and we will help you reset access to the Shaikhoology portal.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
