<?php $title = 'Case Studies'; ob_start(); ?>
<h1>Case Studies</h1>
<p>See how teams validated compliance narratives, managed evidence, and communicated rulings to their investors.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
