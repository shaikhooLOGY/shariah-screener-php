<?php $title = 'Purification Guide'; ob_start(); ?>
<h1>Purification Guide</h1>
<p>Learn how to calculate purification amounts and charitable offsets for investors consuming non-compliant revenue.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
