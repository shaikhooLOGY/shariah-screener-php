<?php $title = 'Terms'; ob_start(); ?>
<h1>Terms of Use</h1>
<p>These terms outline acceptable use, licensing, and data handling for the Shaikhoology screening portal.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
