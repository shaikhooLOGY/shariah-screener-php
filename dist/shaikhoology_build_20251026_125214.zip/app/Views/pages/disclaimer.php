<?php $title = 'Disclaimers'; ob_start(); ?>
<h1>Disclaimers</h1>
<p>Screening outputs support advisory workflows and should be reviewed by qualified scholars before publication.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
