<?php $title = 'Contact'; ob_start(); ?>
<h1>Contact Us</h1>
<p>Reach our screening team for demos, scholar onboarding, or API access details.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
