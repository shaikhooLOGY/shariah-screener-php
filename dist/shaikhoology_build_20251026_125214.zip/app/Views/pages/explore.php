<?php $title = 'Explore'; ob_start(); ?>
<h1>Explore the Coverage</h1>
<p>Browse sectors, filter by compliance status, and discover companies ready for screening conversations.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
