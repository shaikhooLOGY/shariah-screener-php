<?php $title = 'Standards'; ob_start(); ?>
<h1>Standards Comparison</h1>
<p>Compare AAOIFI, OJK, and other regional screening frameworks with actionable commentary for finance teams.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
