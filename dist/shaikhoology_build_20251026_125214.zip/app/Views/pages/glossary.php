<?php $title = 'Glossary'; ob_start(); ?>
<h1>Glossary</h1>
<p>Understand key Arabic, accounting, and screening terminology with concise definitions and references.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
