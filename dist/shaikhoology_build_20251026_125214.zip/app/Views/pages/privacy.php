<?php $title = 'Privacy'; ob_start(); ?>
<h1>Privacy Policy</h1>
<p>We describe how screening data, evidence uploads, and contact details are secured and processed.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
