<?php $title = 'Methodology'; ob_start(); ?>
<h1>Screening Methodology</h1>
<p>Our ratio thresholds follow AAOIFI guidelines with contextual caps for debt, interest, liquidity, and non-compliant income.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
