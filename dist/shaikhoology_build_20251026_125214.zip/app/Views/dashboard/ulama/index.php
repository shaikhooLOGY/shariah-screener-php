<?php $title = 'Ulama Dashboard'; ob_start(); ?>
<h1>Ulama Dashboard</h1>
<p>Monitor pending filings, provide rulings, and track communication with analysts.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../../layout.php'; ?>
