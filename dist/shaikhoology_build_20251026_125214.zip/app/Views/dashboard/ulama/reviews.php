<?php $title = 'Ulama Reviews'; ob_start(); ?>
<h1>Reviews Queue</h1>
<p>Review pending company submissions, add scholarly notes, and approve or request clarification.</p>
<?php $content = ob_get_clean(); include __DIR__ . '/../../layout.php'; ?>
